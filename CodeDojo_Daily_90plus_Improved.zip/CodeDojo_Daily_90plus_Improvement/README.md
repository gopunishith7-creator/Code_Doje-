# CodeDojo Daily — Improved Project

A Node.js + Express + SQLite prototype for the DailyDebug Derby brief.

## Implemented improvements
- User registration and login with bcrypt password hashing.
- Server-side sessions stored in SQLite; HttpOnly and SameSite cookies.
- SQLite tables for users, teams, memberships, problems, private test metadata, submissions and solves.
- Server-side validation, duplicate account handling, team size cap (4), one-team-per-user rule.
- Helmet security headers, JSON body-size limit and authentication rate limiting.
- Private test cases are not exposed by the public problem API.
- First accepted demo solve is recorded once per user/problem.
- Team listing and individual leaderboard APIs.
- Consistent API error responses and a responsive UI.

## Run locally
1. Install Node.js 18 or later.
2. Extract this ZIP and open the folder in VS Code.
3. In a terminal run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set `SESSION_SECRET` to a random string of at least 32 characters.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Demo acceptance
This prototype intentionally does **not** execute arbitrary submitted code. To demonstrate the accepted UI flow, append this exact comment to the editor:
`/* DEMO_ACCEPTED */`

This only simulates the accepted flow; it is not proof that the submitted algorithm is correct. Do not present it as a real code judge.

## Required before production / genuine hackathon judging
A real code runner is not safely implemented by JavaScript `eval`, browser workers, or a normal Express process. Add a separate isolated judge service (container/VM per submission) with CPU, memory and wall-clock limits, no network access, non-root execution, read-only base filesystem, strict output limits, queueing, and server-side hidden-test evaluation. Store judge results server-side and award points only after verified results. Add CSRF protection, email verification, password reset, audit logging, backups, and deployment secrets management before public deployment.

## Project scope
This ZIP is a clean implementation based on the supplied CodeDojo Daily problem brief and evaluation feedback. It is not a patch of the original source code because the original source ZIP was not supplied. Grade outcomes depend on the evaluator; no score is guaranteed.
