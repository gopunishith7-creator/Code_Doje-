# Manual test checklist

- [ ] Register with valid name, email and password (8+ characters).
- [ ] Attempt duplicate registration; expect a conflict message.
- [ ] Login with correct password.
- [ ] Login with incorrect password; expect a generic authentication error.
- [ ] Open challenge list and filter by difficulty.
- [ ] Request a non-existent problem ID; expect 404.
- [ ] Submit without login; expect 401.
- [ ] Submit a short code string; expect validation error.
- [ ] Submit code without the demo marker; expect judge-integration notice.
- [ ] Submit code with `/* DEMO_ACCEPTED */`; observe demo-only accepted status.
- [ ] Create a team; verify team appears in team list.
- [ ] Try creating a second team as same user; expect rejection.
- [ ] Join a team; verify membership count.
- [ ] Try joining another team; expect rejection.
- [ ] Create a team with another account and fill it to four; fifth member should be rejected.
- [ ] Check leaderboard and progress after demo submission.
- [ ] Logout and verify protected submissions require login.
