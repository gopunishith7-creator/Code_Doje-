const $ = s => document.querySelector(s);
let currentUser = null, selectedProblem = null, isRegister = false, allProblems = [];
function notice(msg, bad=false){ $("#notice").textContent=msg; $("#notice").style.color=bad?"#ff9ca8":"#aeb8ff"; }
async function api(url, options={}) {
  const res=await fetch(url,{credentials:"same-origin",headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const data=await res.json().catch(()=>({error:"Invalid server response"}));
  if(!res.ok) throw new Error(data.error||"Request failed");
  return data;
}
function showView(id){ document.querySelectorAll(".view").forEach(x=>x.classList.add("hidden")); $("#"+id).classList.remove("hidden"); }
async function refreshUser(){
  const d=await api("/api/me"); currentUser=d.user;
  $("#account").innerHTML=currentUser?`<span class="muted">Hi, ${escapeHtml(currentUser.name)}</span> <button class="outline" id="logoutBtn">Logout</button>`:`<button class="outline" id="loginBtn">Login / Register</button>`;
  $("#loginBtn")?.addEventListener("click",()=>openAuth(false));
  $("#logoutBtn")?.addEventListener("click",async()=>{await api("/api/auth/logout",{method:"POST"});await refreshUser();notice("Logged out.");});
  if(currentUser){const s=await api("/api/stats");$("#solved").textContent=s.solved;}else $("#solved").textContent="—";
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function loadProblems(){
  const d=await api("/api/problems");allProblems=d.problems;renderProblems();
}
function renderProblems(){
  const diff=$("#difficulty").value;
  $("#problems").innerHTML=allProblems.filter(p=>!diff||p.difficulty===diff).map(p=>`<article class="problem-card"><div class="chips"><span class="chip">${escapeHtml(p.difficulty)}</span><span class="chip">${escapeHtml(p.tag)}</span></div><h3>${escapeHtml(p.title)}</h3><p>${escapeHtml(p.description)}</p><small class="muted">Example: ${escapeHtml(p.sample_input)} → ${escapeHtml(p.sample_output)}</small><button data-problem="${p.id}">Open challenge</button></article>`).join("");
  document.querySelectorAll("[data-problem]").forEach(b=>b.addEventListener("click",()=>openProblem(Number(b.dataset.problem))));
}
async function openProblem(id){
  try{
    const d=await api("/api/problems/"+id);selectedProblem=d.problem;
    $("#problemDetail").innerHTML=`<p class="eyebrow">${escapeHtml(d.problem.tag)} · ${escapeHtml(d.problem.difficulty)}</p><h2>${escapeHtml(d.problem.title)}</h2><p class="muted">${escapeHtml(d.problem.description)}</p><div class="panel"><b>Sample input</b><p>${escapeHtml(d.problem.sample_input)}</p><b>Expected output</b><p>${escapeHtml(d.problem.sample_output)}</p></div>`;
    $("#code").value="// Write your solution here\\n// Add /* DEMO_ACCEPTED */ to demonstrate the prototype accepted flow.";
    $("#result").textContent="";showView("editor");
  }catch(e){notice(e.message,true);}
}
function openAuth(register){isRegister=register;$("#authTitle").textContent=register?"Create your account":"Welcome back";$("#authSubmit").textContent=register?"Register":"Login";$("#nameLabel").classList.toggle("hidden",!register);$("#toggleAuth").textContent=register?"Already registered? Login":"Need an account? Register";$("#authDialog").showModal();}
$("#toggleAuth").addEventListener("click",()=>openAuth(!isRegister));
$("#loginBtn").addEventListener("click",()=>openAuth(false));
$("#authForm").addEventListener("submit",async e=>{
 e.preventDefault();const f=new FormData(e.currentTarget),body=Object.fromEntries(f.entries());
 try{const d=await api(isRegister?"/api/auth/register":"/api/auth/login",{method:"POST",body:JSON.stringify(body)});currentUser=d.user;$("#authDialog").close();await refreshUser();notice("Welcome, "+currentUser.name+"!");}
 catch(err){notice(err.message,true);}
});
$("#difficulty").addEventListener("change",renderProblems);
$("#backBtn").addEventListener("click",()=>showView("home"));
$("#runBtn").addEventListener("click",async()=>{
 if(!currentUser){openAuth(false);return;}
 try{const d=await api("/api/submissions",{method:"POST",body:JSON.stringify({problemId:selectedProblem.id,code:$("#code").value})});$("#result").className=d.status.startsWith("Accepted")?"success":"error";$("#result").textContent=`${d.status} · ${d.passed}/${d.total} demo checks. ${d.message}`;await refreshUser();}
 catch(e){$("#result").className="error";$("#result").textContent=e.message;}
});
$("#teamForm").addEventListener("submit",async e=>{
 e.preventDefault();try{await api("/api/teams",{method:"POST",body:JSON.stringify({name:new FormData(e.currentTarget).get("name"),avatar:"🚀"})});e.currentTarget.reset();notice("Team created!");loadTeams();}
 catch(err){notice(err.message,true);}
});
async function loadTeams(){
 try{const d=await api("/api/teams");$("#teamsList").innerHTML=d.teams.map(t=>`<div class="list-row"><span>${escapeHtml(t.avatar)} <b>${escapeHtml(t.name)}</b> <small class="muted">· ${t.members}/4 members</small></span><span>${t.score} pts</span><button data-join="${t.id}">Join</button></div>`).join("")||'<p class="muted">No teams yet. Create the first one!</p>';
 document.querySelectorAll("[data-join]").forEach(b=>b.addEventListener("click",async()=>{try{await api("/api/teams/"+b.dataset.join+"/join",{method:"POST"});notice("Joined team.");loadTeams();}catch(e){notice(e.message,true);}}));
 }catch(e){notice(e.message,true);}
}
async function loadLeaders(){
 const d=await api("/api/leaderboard");$("#leaders").innerHTML=d.leaders.map((u,i)=>`<div class="list-row"><b>#${i+1} ${escapeHtml(u.name)}</b><span>${u.solved} solved · ${u.points} pts</span></div>`).join("")||'<p class="muted">No scores yet.</p>';
}
document.querySelectorAll("nav [data-view]").forEach(b=>b.addEventListener("click",()=>{const v=b.dataset.view;showView(v);if(v==="teams")loadTeams();if(v==="leaderboard")loadLeaders();}));
(async()=>{try{await refreshUser();await loadProblems();}catch(e){notice("Could not connect to server. Start the app with npm start.",true);}})();
