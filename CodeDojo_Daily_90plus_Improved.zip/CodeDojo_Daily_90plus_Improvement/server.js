const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error("Please set SESSION_SECRET (see .env.example).");
  process.exit(1);
}

fs.mkdirSync(path.join(__dirname, "data"), { recursive: true });
const db = new Database(path.join(__dirname, "data", "codedojo.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS teams (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, avatar TEXT DEFAULT '🚀',
 created_by INTEGER REFERENCES users(id), created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS team_members (
 team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
 user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
 PRIMARY KEY(team_id,user_id), UNIQUE(user_id)
);
CREATE TABLE IF NOT EXISTS problems (
 id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL,
 difficulty TEXT NOT NULL, tag TEXT NOT NULL, sample_input TEXT NOT NULL,
 sample_output TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS private_tests (
 id INTEGER PRIMARY KEY, problem_id INTEGER REFERENCES problems(id) ON DELETE CASCADE,
 input TEXT NOT NULL, expected_output TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS submissions (
 id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id),
 problem_id INTEGER REFERENCES problems(id), status TEXT NOT NULL,
 points INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS solves (
 user_id INTEGER REFERENCES users(id), problem_id INTEGER REFERENCES problems(id),
 solved_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,problem_id)
);
`);

if (db.prepare("SELECT COUNT(*) n FROM problems").get().n === 0) {
  const insert = db.prepare("INSERT INTO problems(title,description,difficulty,tag,sample_input,sample_output) VALUES(?,?,?,?,?,?)");
  const p1 = insert.run("Two Sum Variant", "Given an integer array and a target, return the indices of two distinct values whose sum equals the target.", "Easy", "Arrays", "[2, 7, 11, 15], target = 9", "[0, 1]").lastInsertRowid;
  const p2 = insert.run("Reverse Words", "Reverse the order of words in a sentence without changing the spelling of each word.", "Easy", "Strings", "'code every day'", "'day every code'").lastInsertRowid;
  const p3 = insert.run("Maximum Subarray", "Find the maximum sum of a contiguous, non-empty subarray.", "Medium", "Dynamic Programming", "[-2,1,-3,4,-1,2,1,-5,4]", "6").lastInsertRowid;
  const addTest = db.prepare("INSERT INTO private_tests(problem_id,input,expected_output) VALUES(?,?,?)");
  [[p1,"[3,2,4];6","[1,2]"],[p1,"[3,3];6","[0,1]"],[p1,"[1,5,3,7];8","[0,3]"],
   [p2,"'hello world'","'world hello'"],[p2,"'learn code daily'","'daily code learn'"],
   [p3,"[1]","1"],[p3,"[-2,-1]","-1"],[p3,"[5,4,-1,7,8]","23"]].forEach(x => addTest.run(...x));
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "25kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: path.join(__dirname, "data") }),
  secret: SESSION_SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 25, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

const clean = (v, max = 120) => typeof v === "string" ? v.trim().slice(0, max) : "";
const requireLogin = (req, res, next) => req.session.userId ? next() : res.status(401).json({ error: "Please log in first." });

app.post("/api/auth/register", async (req, res) => {
  const name = clean(req.body.name, 50);
  const email = clean(req.body.email, 120).toLowerCase();
  const password = req.body.password;
  if (name.length < 2 || !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email) || typeof password !== "string" || password.length < 8)
    return res.status(400).json({ error: "Enter a name, valid email and password with at least 8 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name,email,hash);
    req.session.userId = result.lastInsertRowid;
    res.status(201).json({ user: { id: result.lastInsertRowid, name, email } });
  } catch (e) {
    if (String(e).includes("UNIQUE")) return res.status(409).json({ error: "This email is already registered." });
    res.status(500).json({ error: "Registration failed. Please try again." });
  }
});
app.post("/api/auth/login", async (req,res) => {
  const email = clean(req.body.email,120).toLowerCase();
  const password = req.body.password;
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || typeof password !== "string" || !(await bcrypt.compare(password,user.password_hash)))
    return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.userId = user.id;
  res.json({ user: { id:user.id, name:user.name, email:user.email } });
});
app.post("/api/auth/logout",(req,res) => req.session.destroy(() => res.json({ ok:true })));
app.get("/api/me",(req,res) => {
  const user = db.prepare("SELECT id,name,email FROM users WHERE id=?").get(req.session.userId);
  res.json({ user: user || null });
});

app.get("/api/problems",(req,res) => {
  const problems = db.prepare("SELECT id,title,description,difficulty,tag,sample_input,sample_output FROM problems ORDER BY id").all();
  res.json({ problems });
});
app.get("/api/problems/:id",(req,res) => {
  const p = db.prepare("SELECT id,title,description,difficulty,tag,sample_input,sample_output FROM problems WHERE id=?").get(Number(req.params.id));
  if (!p) return res.status(404).json({ error:"Problem not found." });
  res.json({ problem:p });
});

/*
 * IMPORTANT SAFETY/ACCURACY NOTE:
 * This hackathon prototype intentionally does not execute arbitrary user code.
 * The demo marker lets presenters demonstrate the UI flow only.
 * A real judge must run in isolated containers with CPU/memory/time limits,
 * no network, non-root user, read-only filesystem and server-side test cases.
 */
app.post("/api/submissions",requireLogin,(req,res) => {
  const problemId = Number(req.body.problemId);
  const code = clean(req.body.code,15000);
  if (!Number.isInteger(problemId) || !db.prepare("SELECT id FROM problems WHERE id=?").get(problemId))
    return res.status(404).json({ error:"Problem not found." });
  if (code.length < 5) return res.status(400).json({ error:"Enter code before submitting." });
  const acceptedDemo = code.includes("/* DEMO_ACCEPTED */");
  const total = db.prepare("SELECT COUNT(*) n FROM private_tests WHERE problem_id=?").get(problemId).n;
  const status = acceptedDemo ? "Accepted (Demo)" : "Pending Judge Integration";
  const points = acceptedDemo ? 100 : 0;
  const tx = db.transaction(() => {
    db.prepare("INSERT INTO submissions(user_id,problem_id,status,points) VALUES(?,?,?,?)").run(req.session.userId,problemId,status,points);
    if (acceptedDemo) db.prepare("INSERT OR IGNORE INTO solves(user_id,problem_id) VALUES(?,?)").run(req.session.userId,problemId);
  });
  tx();
  res.json({ status, passed:acceptedDemo ? total : 0, total,
    message: acceptedDemo ? "Demo flow passed. This is not real code execution." : "Saved. Connect an isolated server-side judge for actual testcase evaluation." });
});

app.post("/api/teams",requireLogin,(req,res) => {
  const name = clean(req.body.name,32), avatar = clean(req.body.avatar,8) || "🚀";
  if (name.length < 3) return res.status(400).json({ error:"Team name must have at least 3 characters." });
  if (db.prepare("SELECT 1 FROM team_members WHERE user_id=?").get(req.session.userId))
    return res.status(409).json({ error:"You already belong to a team." });
  try {
    const tx = db.transaction(() => {
      const id = db.prepare("INSERT INTO teams(name,avatar,created_by) VALUES(?,?,?)").run(name,avatar,req.session.userId).lastInsertRowid;
      db.prepare("INSERT INTO team_members(team_id,user_id) VALUES(?,?)").run(id,req.session.userId);
      return id;
    });
    res.status(201).json({ teamId:tx() });
  } catch(e) { res.status(409).json({ error:"That team name is already taken." }); }
});
app.post("/api/teams/:id/join",requireLogin,(req,res) => {
  const id = Number(req.params.id);
  if (!db.prepare("SELECT id FROM teams WHERE id=?").get(id)) return res.status(404).json({ error:"Team not found." });
  if (db.prepare("SELECT 1 FROM team_members WHERE user_id=?").get(req.session.userId)) return res.status(409).json({ error:"You already belong to a team." });
  if (db.prepare("SELECT COUNT(*) n FROM team_members WHERE team_id=?").get(id).n >= 4) return res.status(409).json({ error:"Team is full (maximum 4 members)." });
  db.prepare("INSERT INTO team_members(team_id,user_id) VALUES(?,?)").run(id,req.session.userId);
  res.json({ ok:true });
});
app.get("/api/teams",(req,res) => {
  const teams = db.prepare(`SELECT t.id,t.name,t.avatar,COUNT(DISTINCT tm.user_id) members,
    COALESCE(SUM(DISTINCT CASE WHEN s.status LIKE 'Accepted%' THEN s.points END),0) score
    FROM teams t LEFT JOIN team_members tm ON tm.team_id=t.id
    LEFT JOIN submissions s ON s.user_id=tm.user_id GROUP BY t.id ORDER BY score DESC,t.name`).all();
  res.json({ teams });
});
app.get("/api/leaderboard",(req,res) => {
  const leaders = db.prepare(`SELECT u.name,COUNT(DISTINCT so.problem_id) solved,
    COALESCE(SUM(DISTINCT CASE WHEN s.status LIKE 'Accepted%' THEN s.points END),0) points
    FROM users u LEFT JOIN solves so ON so.user_id=u.id
    LEFT JOIN submissions s ON s.user_id=u.id GROUP BY u.id ORDER BY points DESC,solved DESC LIMIT 20`).all();
  res.json({ leaders });
});
app.get("/api/stats",requireLogin,(req,res) => {
  const solved = db.prepare("SELECT COUNT(*) n FROM solves WHERE user_id=?").get(req.session.userId).n;
  const submissions = db.prepare("SELECT COUNT(*) n FROM submissions WHERE user_id=?").get(req.session.userId).n;
  res.json({ solved, submissions });
});
app.use("/api",(err,req,res,next) => {
  console.error(err);
  res.status(500).json({ error:"Unexpected server error. Please try again." });
});
app.listen(PORT,() => console.log(`CodeDojo Daily running at http://localhost:${PORT}`));
